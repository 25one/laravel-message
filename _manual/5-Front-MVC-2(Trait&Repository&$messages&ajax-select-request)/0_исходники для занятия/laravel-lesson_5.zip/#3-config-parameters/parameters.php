<?php

return [

    'front' => [
           'order' => 'type_id',
           'direction' => 'desc',
    ],

    'back' => [
        'order' => 'user_id',
        'direction' => 'asc',
    ],

];
